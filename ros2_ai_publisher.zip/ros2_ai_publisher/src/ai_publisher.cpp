#include "ros2_ai_publisher/ai_publisher.hpp"
#include <functional>

namespace ros2_ai_publisher
{
AiPublisher::AiPublisher(const rclcpp::NodeOptions & options)
: Node("ai_publisher", options)
{
  // Relative topic names allow launch namespaces and standard ROS remapping.
  const auto qos = rclcpp::QoS(rclcpp::KeepLast(10)).reliable();
  prompt_publisher_ = create_publisher<std_msgs::msg::String>("ai/prompt", qos);
  output_publisher_ = create_publisher<std_msgs::msg::String>("ai/output", qos);
  input_subscription_ = create_subscription<std_msgs::msg::String>(
    "ai/input", qos, std::bind(&AiPublisher::on_input, this, std::placeholders::_1));
  result_subscription_ = create_subscription<std_msgs::msg::String>(
    "ai/result", qos, std::bind(&AiPublisher::on_result, this, std::placeholders::_1));
  RCLCPP_INFO(get_logger(), "Ready: ai/input -> ai/prompt; ai/result -> ai/output");
}

void AiPublisher::on_input(const std_msgs::msg::String::ConstSharedPtr message)
{
  // Volatile QoS does not retain prompts: avoid silently dropping input on startup.
  if (prompt_publisher_->get_subscription_count() == 0U) {
    RCLCPP_WARN(get_logger(), "No AI bridge discovered. Retry when the bridge is ready.");
    return;
  }
  prompt_publisher_->publish(*message);
}

void AiPublisher::on_result(const std_msgs::msg::String::ConstSharedPtr message)
{
  output_publisher_->publish(*message);
  // Do not log prompt/response contents; they may contain private data.
  RCLCPP_INFO(get_logger(), "Published AI response (%zu bytes)", message->data.size());
}
}  // namespace ros2_ai_publisher
