#include "ros2_ai_publisher/ai_publisher.hpp"
#include <memory>

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<ros2_ai_publisher::AiPublisher>());
  rclcpp::shutdown();
  return 0;
}
