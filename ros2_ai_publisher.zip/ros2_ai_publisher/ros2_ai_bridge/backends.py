"""Small interchangeable text backends, independent of ROS for unit testing."""
from abc import ABC, abstractmethod
import os


class TextBackend(ABC):
    """Contract: generate returns nonempty text or raises an exception."""

    @abstractmethod
    def generate(self, prompt: str) -> str:
        raise NotImplementedError


def require_text(value):
    """Reject empty/refusal-only/nontext output rather than publishing success."""
    if not isinstance(value, str) or not value.strip():
        raise ValueError("Provider returned no text")
    return value.strip()


class MockBackend(TextBackend):
    def generate(self, prompt):
        return "[mock] " + prompt


class OpenAIBackend(TextBackend):
    def __init__(self, model, instructions, timeout, max_tokens):
        from openai import OpenAI
        # Fixed official endpoint; the key comes only from the environment.
        self.client = OpenAI(base_url="https://api.openai.com/v1",
                             timeout=timeout, max_retries=0)
        self.model, self.instructions = model, instructions
        self.max_tokens = max_tokens

    def generate(self, prompt):
        response = self.client.responses.create(
            model=self.model, instructions=self.instructions, input=prompt,
            max_output_tokens=self.max_tokens, store=False)
        if response.status != "completed":
            raise ValueError("Provider response did not complete")
        return require_text(response.output_text)


class LangChainBackend(TextBackend):
    def __init__(self, model, instructions, timeout, max_tokens):
        from langchain_openai import ChatOpenAI
        from langchain_core.prompts import ChatPromptTemplate
        from langchain_core.output_parsers import StrOutputParser
        llm = ChatOpenAI(model=model, timeout=timeout, max_retries=0,
                         max_tokens=max_tokens, use_responses_api=True,
                         base_url="https://api.openai.com/v1", store=False)
        # Instructions are a variable too: literal braces in them remain literal.
        template = ChatPromptTemplate.from_messages([
            ("system", "{instructions}"), ("human", "{prompt}")])
        self.chain = template | llm | StrOutputParser()
        self.instructions = instructions

    def generate(self, prompt):
        return require_text(self.chain.invoke(
            {"instructions": self.instructions, "prompt": prompt}))


def make_backend(name, model, instructions, timeout, max_tokens):
    """Fail early for a wrong backend, missing key, or missing model."""
    if name == "mock":
        return MockBackend()
    classes = {"openai": OpenAIBackend, "langchain": LangChainBackend}
    if name not in classes:
        raise ValueError("backend must be mock, openai, or langchain")
    if not os.environ.get("OPENAI_API_KEY", "").strip():
        raise ValueError("OPENAI_API_KEY must be set for a live backend")
    if not model.strip():
        raise ValueError("Set model to a model ID available to your API project")
    return classes[name](model, instructions, timeout, max_tokens)
