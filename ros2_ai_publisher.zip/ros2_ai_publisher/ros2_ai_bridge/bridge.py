"""ROS adapter: one background inference at a time, responsive ROS callbacks."""
from concurrent.futures import ThreadPoolExecutor
import math
import sys

import rclpy
from rclpy.executors import ExternalShutdownException
from rcl_interfaces.msg import ParameterDescriptor
from rclpy.node import Node
from std_msgs.msg import String

from ros2_ai_bridge.backends import make_backend


class LlmBridge(Node):
    """Receives text prompts and publishes successful text or separate errors."""

    def __init__(self):
        super().__init__("llm_bridge")
        # Configuration is read once. Prevent misleading runtime parameter changes.
        descriptor = ParameterDescriptor(read_only=True)
        defaults = {
            "backend": "mock", "model": "",
            "instructions": "You are a concise robotics teaching assistant.",
            "timeout_sec": 30.0, "max_output_tokens": 512,
            "max_prompt_chars": 4000,
        }
        for name, value in defaults.items():
            self.declare_parameter(name, value, descriptor)
        values = {name: self.get_parameter(name).value for name in defaults}
        timeout = values["timeout_sec"]
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("timeout_sec must be finite and positive")
        if values["max_output_tokens"] <= 0 or values["max_prompt_chars"] <= 0:
            raise ValueError("Token and prompt limits must be positive")
        self.max_prompt_chars = values["max_prompt_chars"]
        self.backend = make_backend(values["backend"], values["model"],
                                    values["instructions"], timeout,
                                    values["max_output_tokens"])
        self.result_pub = self.create_publisher(String, "ai/result", 10)
        self.error_pub = self.create_publisher(String, "ai/error", 10)
        self.subscription = self.create_subscription(String, "ai/prompt", self.on_prompt, 10)
        self.worker = ThreadPoolExecutor(max_workers=1, thread_name_prefix="llm")
        self.pending = None
        self.poll_timer = self.create_timer(0.05, self.poll_result)
        self.get_logger().info("AI bridge ready; backend=" + values["backend"])

    def error(self, code):
        """Only sanitized codes leave the node; no raw API error bodies or keys."""
        self.error_pub.publish(String(data=code))
        self.get_logger().warning(code)

    def on_prompt(self, message):
        prompt = message.data.strip()
        if not prompt:
            self.error("invalid_prompt: empty")
        elif len(prompt) > self.max_prompt_chars:
            self.error("invalid_prompt: too_long")
        elif self.pending is not None:
            # No hidden unbounded queue or unexpected series of billable calls.
            self.error("busy: retry_after_current_response")
        else:
            self.pending = self.worker.submit(self.backend.generate, prompt)

    def poll_result(self):
        """Only the ROS executor publishes; the worker performs network I/O."""
        if self.pending is None or not self.pending.done():
            return
        future, self.pending = self.pending, None
        try:
            text = future.result()
        except Exception:
            self.error("provider_error: check_key_model_quota_network_or_response")
        else:
            self.result_pub.publish(String(data=text))

    def destroy_node(self):
        self.poll_timer.cancel()
        # An already running request completes/times out before process exit.
        self.worker.shutdown(wait=True, cancel_futures=True)
        return super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = None
    exit_code = 0
    try:
        node = LlmBridge()
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    except Exception:
        # Avoid SDK exception bodies, which can contain submitted data.
        print("Bridge failed: check parameters, API key and optional Python dependencies.",
              file=sys.stderr)
        exit_code = 1
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
    return exit_code
