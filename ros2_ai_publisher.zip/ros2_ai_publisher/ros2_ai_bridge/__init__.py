"""ROS 2 bridge package; optional AI libraries are imported only when selected."""
