"""Real ROS graph tests, including the compiled C++ executable; no API access."""
import os
import signal
import subprocess
import sys
import time
from concurrent.futures import Future

import pytest
import rclpy
from rclpy.executors import SingleThreadedExecutor
from rclpy.parameter import Parameter
from std_msgs.msg import String
from ros2_ai_bridge.bridge import LlmBridge


@pytest.fixture
def context():
    rclpy.init()
    yield
    rclpy.shutdown()


def spin_until(executor, predicate, timeout=12):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        executor.spin_once(timeout_sec=0.05)
        if predicate():
            return
    raise AssertionError('Timed out waiting for ROS message/discovery')


def test_cpp_bridge_roundtrip(context, tmp_path):
    cpp = os.environ['AI_CPP_EXECUTABLE']
    script = os.environ['AI_BRIDGE_EXECUTABLE']
    processes = []
    logs = []
    node = rclpy.create_node('integration_observer')
    executor = SingleThreadedExecutor()
    executor.add_node(node)
    outputs, errors = [], []
    node.create_subscription(String, 'ai/output', lambda msg: outputs.append(msg.data), 10)
    node.create_subscription(String, 'ai/error', lambda msg: errors.append(msg.data), 10)
    publisher = node.create_publisher(String, 'ai/input', 10)
    try:
        for index, command in enumerate(([cpp], [sys.executable, script])):
            log = open(tmp_path / f'node_{index}.log', 'w+')
            logs.append(log)
            processes.append(subprocess.Popen(command, stdout=log, stderr=log))
        spin_until(executor, lambda: publisher.get_subscription_count() > 0
                   and node.count_subscribers('ai/prompt') > 0
                   and node.count_subscribers('ai/result') > 0
                   and node.count_publishers('ai/output') > 0
                   and node.count_publishers('ai/error') > 0)
        # Discovery of remote endpoints is asynchronous in each participant.
        for _ in range(20):
            executor.spin_once(timeout_sec=0.05)
        publisher.publish(String(data='Explain DVL navigation'))
        spin_until(executor, lambda: len(outputs) == 1)
        assert outputs == ['[mock] Explain DVL navigation']
        publisher.publish(String(data='   '))
        spin_until(executor, lambda: len(errors) == 1)
        assert errors[-1] == 'invalid_prompt: empty'
        publisher.publish(String(data='x' * 4001))
        spin_until(executor, lambda: len(errors) == 2)
        assert errors[-1] == 'invalid_prompt: too_long'
        publisher.publish(String(data='Second request'))
        spin_until(executor, lambda: len(outputs) == 2)
        assert outputs[-1] == '[mock] Second request'
        assert all(process.poll() is None for process in processes)
    finally:
        for process in processes:
            if process.poll() is None:
                process.send_signal(signal.SIGINT)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        executor.shutdown()
        node.destroy_node()
        for log in logs:
            log.seek(0)
            print(log.read())
            log.close()


def test_busy_failure_recovery_and_read_only_parameters(context):
    bridge = LlmBridge()
    observer = rclpy.create_node('error_observer')
    executor = SingleThreadedExecutor()
    executor.add_node(bridge)
    executor.add_node(observer)
    errors, results = [], []
    observer.create_subscription(String, 'ai/error', lambda msg: errors.append(msg.data), 10)
    observer.create_subscription(String, 'ai/result', lambda msg: results.append(msg.data), 10)
    try:
        spin_until(executor, lambda: bridge.error_pub.get_subscription_count() > 0
                   and bridge.result_pub.get_subscription_count() > 0)
        assert not bridge.set_parameters([Parameter('backend', value='openai')])[0].successful
        future = Future()
        bridge.pending = future
        bridge.on_prompt(String(data='another request'))
        spin_until(executor, lambda: len(errors) == 1)
        assert errors[-1].startswith('busy:')
        future.set_exception(RuntimeError('private fake API error body'))
        spin_until(executor, lambda: len(errors) == 2)
        assert errors[-1] == 'provider_error: check_key_model_quota_network_or_response'
        bridge.on_prompt(String(data='recovery'))
        spin_until(executor, lambda: bool(results))
        assert results == ['[mock] recovery']
    finally:
        executor.shutdown()
        bridge.destroy_node()
        observer.destroy_node()
