"""Optional real-SDK tests; replace HTTP transport, never call OpenAI servers.

Run after installing requirements.txt:
  python -m pytest test/optional -v
"""
import json
import pytest

httpx = pytest.importorskip('httpx')
pytest.importorskip('openai')
pytest.importorskip('langchain_openai')
from ros2_ai_bridge.backends import make_backend


@pytest.mark.parametrize('backend_name', ['openai', 'langchain'])
def test_real_sdk_request_and_response(monkeypatch, backend_name):
    monkeypatch.setenv('OPENAI_API_KEY', 'offline-test-placeholder')
    requests = []

    def fake_send(client, request, **kwargs):
        requests.append(request)
        return httpx.Response(200, request=request, json={
            'id': 'resp_offline', 'object': 'response', 'created_at': 1700000000,
            'status': 'completed', 'model': 'gpt-4.1-mini',
            'error': None, 'incomplete_details': None,
            'output': [{'id': 'msg_offline', 'type': 'message',
                        'status': 'completed', 'role': 'assistant',
                        'content': [{'type': 'output_text', 'text': 'Offline SDK answer',
                                     'annotations': []}]}],
            'usage': {'input_tokens': 10, 'output_tokens': 4, 'total_tokens': 14,
                      'input_tokens_details': {'cached_tokens': 0},
                      'output_tokens_details': {'reasoning_tokens': 0}},
        })

    monkeypatch.setattr(httpx.Client, 'send', fake_send)
    backend = make_backend(backend_name, 'gpt-4.1-mini', 'Teach {literally}', 2.0, 64)
    assert backend.generate('What is a DVL?') == 'Offline SDK answer'
    assert len(requests) == 1
    assert str(requests[0].url) == 'https://api.openai.com/v1/responses'
    body = json.loads(requests[0].content)
    assert body['model'] == 'gpt-4.1-mini'
    assert body['max_output_tokens'] == 64
    assert body['store'] is False
    assert 'What is a DVL?' in json.dumps(body)
    assert 'Teach {literally}' in json.dumps(body)
