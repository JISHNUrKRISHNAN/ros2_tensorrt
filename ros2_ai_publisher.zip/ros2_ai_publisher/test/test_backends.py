"""Offline contract tests: SDK fakes verify arguments without billable requests."""
import sys
from types import SimpleNamespace
from unittest.mock import MagicMock
import pytest
from ros2_ai_bridge.backends import make_backend, require_text


def test_mock_without_key(monkeypatch):
    monkeypatch.delenv('OPENAI_API_KEY', raising=False)
    assert make_backend('mock', '', '', 1.0, 50).generate('hello') == '[mock] hello'


@pytest.mark.parametrize('value', ['', '   ', None, []])
def test_no_text(value):
    with pytest.raises(ValueError):
        require_text(value)


def test_invalid_backend():
    with pytest.raises(ValueError, match='backend'):
        make_backend('wrong', '', '', 1.0, 50)


def test_missing_key(monkeypatch):
    monkeypatch.delenv('OPENAI_API_KEY', raising=False)
    with pytest.raises(ValueError, match='OPENAI_API_KEY'):
        make_backend('openai', 'test-model', '', 1.0, 50)


def test_missing_model(monkeypatch):
    monkeypatch.setenv('OPENAI_API_KEY', 'test-placeholder')
    with pytest.raises(ValueError, match='model'):
        make_backend('langchain', '', '', 1.0, 50)


def test_openai_request_and_incomplete_response(monkeypatch):
    monkeypatch.setenv('OPENAI_API_KEY', 'test-placeholder')
    client = MagicMock()
    constructor = MagicMock(return_value=client)
    monkeypatch.setitem(sys.modules, 'openai', SimpleNamespace(OpenAI=constructor))
    backend = make_backend('openai', 'test-model', 'teach', 2.0, 60)
    client.responses.create.return_value = SimpleNamespace(status='completed', output_text=' answer ')
    assert backend.generate('question') == 'answer'
    constructor.assert_called_once_with(base_url='https://api.openai.com/v1', timeout=2.0, max_retries=0)
    client.responses.create.assert_called_once_with(model='test-model', instructions='teach',
                                                   input='question', max_output_tokens=60, store=False)
    client.responses.create.return_value.status = 'incomplete'
    with pytest.raises(ValueError):
        backend.generate('question')


def test_langchain_composition(monkeypatch):
    monkeypatch.setenv('OPENAI_API_KEY', 'test-placeholder')
    model = MagicMock()
    template = MagicMock()
    parser = MagicMock()
    chain = template.__or__.return_value.__or__.return_value
    chain.invoke.return_value = ' answer '
    factory = MagicMock(return_value=model)
    prompt_class = SimpleNamespace(from_messages=MagicMock(return_value=template))
    monkeypatch.setitem(sys.modules, 'langchain_openai', SimpleNamespace(ChatOpenAI=factory))
    monkeypatch.setitem(sys.modules, 'langchain_core.prompts', SimpleNamespace(ChatPromptTemplate=prompt_class))
    monkeypatch.setitem(sys.modules, 'langchain_core.output_parsers', SimpleNamespace(StrOutputParser=MagicMock(return_value=parser)))
    backend = make_backend('langchain', 'test-model', 'teach {literally}', 2.0, 60)
    assert backend.generate('question') == 'answer'
    template.__or__.assert_called_once_with(model)
    chain.invoke.assert_called_once_with({'instructions': 'teach {literally}', 'prompt': 'question'})
    assert factory.call_args.kwargs['max_retries'] == 0
    assert factory.call_args.kwargs['use_responses_api'] is True
