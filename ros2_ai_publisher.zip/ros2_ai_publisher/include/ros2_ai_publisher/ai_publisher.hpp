#ifndef ROS2_AI_PUBLISHER__AI_PUBLISHER_HPP_
#define ROS2_AI_PUBLISHER__AI_PUBLISHER_HPP_

#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>

namespace ros2_ai_publisher
{
/// Owns ROS interfaces; forwards prompts and publishes generated text.
class AiPublisher final : public rclcpp::Node
{
public:
  explicit AiPublisher(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  void on_input(const std_msgs::msg::String::ConstSharedPtr message);
  void on_result(const std_msgs::msg::String::ConstSharedPtr message);
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr prompt_publisher_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr output_publisher_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr input_subscription_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr result_subscription_;
};
}  // namespace ros2_ai_publisher
#endif  // ROS2_AI_PUBLISHER__AI_PUBLISHER_HPP_
