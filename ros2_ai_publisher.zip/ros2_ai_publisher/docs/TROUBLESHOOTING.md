# Troubleshooting

| Symptom | Check / action |
|---|---|
| Package not found | Source ROS, then `~/ai_ws/install/setup.bash`; verify folder is inside `src`. |
| Missing ament/rclcpp | Run rosdep after sourcing the selected ROS distribution. |
| `No module named rclpy` | Use system Python matching ROS, a `--system-site-packages` venv, and source ROS. |
| Missing `openai` / `langchain_openai` | Activate the venv in the launching terminal and install `requirements.txt`. |
| Generic bridge startup error | Check key presence, model, backend spelling, positive limits, and optional imports. |
| No output | Start the echo first, wait for bridge discovery, then send a fresh prompt. Check `ai/error`. |
| C++ says no bridge discovered | Start `llm_bridge`, wait for discovery and retry the prompt. |
| `busy` | Wait for the outstanding response/error, then submit again. No automatic retry occurs. |
| `provider_error` | Check API key, project access, quota, network and model ID; increase token budget if output is incomplete. |
| Parameter update rejected | Parameters are read-only; restart with new YAML/CLI values. |
| Tests cannot discover nodes | Stop other demos; use a free ROS_DOMAIN_ID and allow local DDS traffic. |
| Cross-distribution errors | Delete build/install/log in your own workspace and rebuild in a fresh terminal sourced for one distro. |
| Slow shutdown | An in-flight request is finishing or waiting on the SDK timeout. |

Useful checks (run inside the same sourced/activated environment):

```bash
ros2 pkg executables ros2_ai_publisher
ros2 node list
ros2 topic list -t
ros2 topic info /ai/prompt --verbose
ros2 param list /llm_bridge
python3 -c 'import rclpy; print("rclpy OK")'
python3 -c 'import openai; print("OpenAI SDK OK")'
python3 -c 'import langchain_openai; print("LangChain SDK OK")'
```

The package intentionally does not print API keys, prompts, raw responses or
provider error bodies. Model access and live API behavior must be verified with
your own account. The included offline tests cannot establish account access,
model availability, billing or real network behavior.
