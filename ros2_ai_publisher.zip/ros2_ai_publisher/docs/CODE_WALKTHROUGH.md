# Code walkthrough

## Files and responsibilities

| File | Responsibility |
|---|---|
| `include/ros2_ai_publisher/ai_publisher.hpp` | C++ class declaration and owned ROS handles |
| `src/ai_publisher.cpp` | Publisher/subscriber setup and message callbacks |
| `src/main.cpp` | ROS initialization, spinning and shutdown |
| `ros2_ai_bridge/backends.py` | Interchangeable mock/OpenAI/LangChain clients |
| `ros2_ai_bridge/bridge.py` | Python ROS node and background request execution |
| `ros2_ai_bridge/__init__.py` | Makes the bridge importable as a Python package |
| `scripts/llm_bridge` | Executable wrapper returning the bridge exit status |
| `launch/ai_demo.launch.py` | Launch arguments and simultaneous node startup |
| `config/params.yaml` | Shared defaults matched under any namespace |
| `CMakeLists.txt` | C++ build, Python installation, data installation, tests |
| `package.xml` | Package metadata and ROS/rosdep dependencies |
| `requirements.txt` | Optional live-backend Python SDK dependencies |
| `test/test_backends.py` | Backend behavior and SDK call contract tests |
| `test/test_integration.py` | Actual C++/Python ROS messaging and error tests |
| `test/optional/test_sdk_transport.py` | Real SDK serialization/parsing with intercepted HTTP |
| `.github/workflows/ros-build.yml` | Offline build/test matrix for two ROS releases |

## C++ object-oriented structure

`AiPublisher final : public rclcpp::Node` uses inheritance to become a ROS node.
Its publishers and subscribers are private members, so their lifetime is tied
to the object. Shared ROS handles provide automatic resource cleanup. `final`
expresses that the example does not expect further subclasses. The public
constructor accepts `NodeOptions` so callers can configure ROS behavior.

The constructor creates two publishers and two subscriptions. `std::bind`
connects member functions to ROS callbacks while retaining access to `this`.
The handles remain alive as members; creating local-only subscriptions would
allow them to be destroyed as soon as the constructor returns.

`on_input(message)` checks whether the bridge has been discovered, then
publishes the input text to `ai/prompt`. This check is advisory: discovery is
asynchronous and is not a delivery acknowledgment. If no bridge is visible,
the node logs a warning and the user must retry. It does not buffer input.

`on_result(message)` publishes the bridge's generated text to `ai/output`.
Only byte count is logged, not the content. Messages are accepted from ROS
publishers without application authentication; use a trusted ROS graph or
configure ROS security when appropriate.

`main()` initializes the ROS context, constructs the node, and calls `spin()`.
The executor runs callbacks until shutdown. There are no blocking HTTP calls
in the C++ node and no cyclic AI requests.

## Python backend abstraction

`TextBackend` defines the abstract `generate(prompt) -> str` contract.
`MockBackend` adds `[mock] ` to the prompt, making tests deterministic.
`require_text()` rejects empty/non-string results and trims returned text.

`OpenAIBackend` lazily imports the optional OpenAI SDK and creates one reusable
client with the official endpoint, configurable timeout and zero retries.
`generate()` calls the Responses API with model, instructions, prompt, output
budget and `store=False`. It requires a completed response and extracts the
SDK's aggregated `output_text` property.

`LangChainBackend` lazily imports `ChatOpenAI`, `ChatPromptTemplate`, and
`StrOutputParser`. The `|` operator composes a runnable chain:

```text
{instructions}, {prompt} -> ChatPromptTemplate -> ChatOpenAI -> StrOutputParser
```

Both template fields are variables so braces inside user-supplied instructions
are data, not additional template variables. `ChatOpenAI` explicitly uses the
Responses API. The text parser returns the answer; an empty answer is rejected.
Unlike the direct backend, this simple adapter does not inspect raw provider
completion status, so a token-limited nonempty LangChain answer may be partial.

`make_backend()` selects the implementation and rejects unknown backends,
missing keys and missing model IDs. Mock mode does not import either optional
AI SDK. It is therefore buildable/testable on a base ROS installation.

## ROS bridge concurrency and errors

`LlmBridge.__init__()` declares typed, read-only parameters, validates positive
limits, creates a backend and creates the result/error publishers and prompt
subscription. It starts one worker and a 50 ms result-poll timer.

`on_prompt()` runs in the ROS executor. It trims and validates input, rejects
requests while busy, or submits `backend.generate()` to the worker. It never
waits for HTTP. The worker has only one outstanding future and no application
backlog. DDS itself still has its configured depth of 10 messages.

`poll_result()` checks the future without blocking. It clears the pending slot,
retrieves the completed result, and publishes either text or a sanitized error
code. Clearing the slot on failure allows the next request to succeed. ROS
publishing remains in the executor thread, not the network worker.

`error()` publishes a stable diagnostic code and logs it. Raw exception text
is deliberately omitted because providers may include submitted data in it.
The sample favors a simple diagnostic interface over rich provider-specific
error reporting.

`destroy_node()` cancels the polling timer and joins the worker before removing
ROS resources. The SDK timeout limits normal network waits, but thread joins
are not hard-deadline cancellation. `main()` handles Ctrl+C, external ROS
shutdown and startup errors, and returns nonzero on a startup/runtime failure.

## Topic contract

All messages are plain text `std_msgs/msg/String`:

| Topic | Writer | Reader | Meaning |
|---|---|---|---|
| `ai/input` | User/application | C++ | New prompt |
| `ai/prompt` | C++ | Bridge | Prompt forwarded for inference |
| `ai/result` | Bridge | C++ | Successful generated text |
| `ai/output` | C++ | User/application | Public answer |
| `ai/error` | Bridge | User/application | Diagnostic code |

Error codes: `invalid_prompt: empty`, `invalid_prompt: too_long`,
`busy: retry_after_current_response`, and
`provider_error: check_key_model_quota_network_or_response`.

Do not remap an output back to an input: that would create a message loop.
There is no exactly-once delivery, persistence or client correlation protocol.

## Build system

CMake finds `ament_cmake`, `ament_cmake_python`, `rclcpp`, and `std_msgs`.
`add_executable` compiles the two C++ source files into `ai_publisher` with
C++17. `ament_target_dependencies` supplies the ROS headers and link settings.
Warnings are enabled for GCC and Clang.

`ament_python_install_package` installs `ros2_ai_bridge` into the workspace's
Python path. `install(PROGRAMS ...)` installs its executable under
`lib/ros2_ai_publisher`, where `ros2 run` can locate it. A mixed ament CMake
package does not need `setup.py` or `setup.cfg`. Those are typical of an
`ament_python` package, not this build type.

Launch/config/docs are installed under `share/ros2_ai_publisher`.
`ament_package()` registers the package in the ament index.
The `BUILD_TESTING` block registers two pytest suites. CMake passes the actual
compiled executable path into the integration test; it does not mock C++.

`package.xml` lists ROS dependencies. Optional pip packages are kept separate
so rosdep/build/mock tests do not require API SDK installation or credentials.
No Humble/Jazzy-specific API conditional is needed: the code uses common ROS 2
publisher/subscriber, parameter, launch and ament APIs.

## Extending the example

To use sensor summaries, publish a short textual summary to `ai/input` at a
controlled low rate, waiting for the response before submitting another prompt.
To add a backend, subclass `TextBackend` and register it in `make_backend()`.
For structured outputs, define custom ROS messages with request IDs and validate
AI output before publishing into any downstream decision-making interface.
