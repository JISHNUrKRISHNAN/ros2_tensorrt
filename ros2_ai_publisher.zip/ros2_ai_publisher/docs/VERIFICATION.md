# Verification report — 26 September 2026

## Results actually observed

| Check | Result |
|---|---|
| Ubuntu 24.04.5 / ROS 2 Jazzy C++ build and install | PASS |
| C++ compiler | GCC 13.3.0, C++17, warning flags enabled |
| Python interpreter | 3.12.3 |
| Backend unit tests with SDK fakes | 10 passed |
| ROS integration tests with actual compiled C++ | 2 passed |
| Actual OpenAI SDK with intercepted HTTP transport | 1 passed |
| Actual LangChain chain with intercepted HTTP transport | 1 passed |
| Installed `ros2 launch`, YAML loading and namespace round trip | PASS |
| Installed executable discovery through `ros2 pkg executables` | Both executables found |
| Humble build/runtime | NOT RUN — Humble is not installed here |
| Live OpenAI calls/account/model access | NOT RUN — no API key; no paid calls made |
| Supplied GitHub Actions Humble/Jazzy matrix | PROVIDED, not executed here |

There are **14 distinct pytest cases** in total: 12 standard cases and 2
optional real-SDK cases. Separately, `colcon test-result` reports `14 tests`
for the standard suite because it counts 12 pytest cases plus two CTest
wrappers. Do not add those wrappers to the distinct-case count.

Final standard result:

```text
Summary: 14 tests, 0 errors, 0 failures, 0 skipped
```

Optional real-SDK result:

```text
2 passed
```

The actual SDKs installed for the additional compatibility check were:

- `openai==2.54.0`
- `langchain-openai==1.6.6`
- `langchain-core==1.6.5`

Those two tests exercise the real client constructors, LangChain composition,
HTTP request serialization and Responses API response parsing. HTTP sending is
replaced with an in-memory fixture; this does not prove live service access.
The fixture's model ID is only test data, not a model availability claim.
Other versions within `requirements.txt` ranges were not exhaustively tested.

## What the integration tests verify

- A separate compiled C++ process receives `ai/input` and publishes `ai/prompt`.
- A separate Python bridge returns mock text on `ai/result`.
- The C++ process publishes that text on `ai/output`.
- Empty and excessive-length prompts produce errors.
- The bridge rejects requests while busy rather than building a queue.
- Provider exceptions do not expose the raw error body and do not prevent a
  later successful request.
- Runtime changes to startup-only parameters are rejected.
- The installed launch file starts both nodes under `/smoke`, reads its YAML,
  and returns `[mock] Installed launch test` through the full graph.

DDS needed local network permission in the testing sandbox. The initial test
harness had an environment-variable append error; it was corrected to set the
executable path with `ENV`, and the final standard tests all passed. An initial
install was started before README generation finished; rerunning after the
files were complete succeeded. These were development runs, not final results.

## Commands used in the task workspace

```bash
source /opt/ros/jazzy/setup.bash
colcon --log-base work/ros_build/log build \
  --base-paths outputs/ros2_ai_publisher \
  --build-base work/ros_build/build \
  --install-base work/ros_build/install
source work/ros_build/install/setup.bash
ROS_LOG_DIR="$PWD/work/ros_build/ros_logs" ROS_DOMAIN_ID=91 \
  colcon --log-base work/ros_build/log test \
  --build-base work/ros_build/build \
  --install-base work/ros_build/install \
  --packages-select ros2_ai_publisher
colcon test-result --test-result-base work/ros_build/build --verbose
PYTHONPATH="$PWD/outputs/ros2_ai_publisher" \
  work/sdk_venv/bin/python -m pytest \
  outputs/ros2_ai_publisher/test/optional -v
```

For your normal workspace, use the simpler build/run commands in `README.md`.
Raw final result XML files are included under `docs/test_results/`.

## Compatibility scope

The source uses common Humble/Jazzy APIs and Python syntax compatible with
Python 3.10+. It is intended for both distributions, but only Jazzy has been
compiled and run here. Run the included CI matrix or the README commands on
Ubuntu 22.04/Humble before treating Humble support as independently verified.
