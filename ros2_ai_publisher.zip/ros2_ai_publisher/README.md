# Integrating OpenAI / LangChain with a ROS 2 C++ Publisher

A small, object-oriented ROS 2 package for **Humble on Ubuntu 22.04** and
**Jazzy on Ubuntu 24.04**. C++17 owns the ROS publisher/subscriber interface;
a Python node provides the OpenAI SDK or LangChain integration. The default
mock backend runs offline and requires no API key or AI libraries.

This is a mixed C++/Python `ament_cmake` package, not an entirely C++ LangChain
implementation. Keeping LangChain in Python makes its documented integration
usable while keeping the robot-facing publisher in C++.

## What it does

```text
Your terminal / application
    | std_msgs/msg/String
    v
ai/input -> C++ AiPublisher -> ai/prompt
                                  |
                           Python LlmBridge
                           worker thread
                           mock / OpenAI / LangChain
                                  |
                             ai/result
                                  v
                           C++ AiPublisher -> ai/output

Invalid requests / backend errors ---------> ai/error
```

All topics are relative, reliable, volatile, KeepLast(10). With the default
namespace they appear as `/ai/input`, `/ai/prompt`, `/ai/result`, `/ai/output`,
and `/ai/error`. All use `std_msgs/msg/String`. The public interface is
`ai/input` and `ai/output`; `ai/prompt` and `ai/result` connect the two nodes.
There is no conversation memory, automatic prompt timer, tool execution, PID
controller or actuator command generation. The output is text.

## 1. Prepare a workspace

Install ROS 2 Humble or Jazzy using the official instructions for your Ubuntu
version. Use only one distribution in a terminal/workspace. Examples below
assume that ROS and rosdep have already been installed and rosdep initialized.

```bash
# Pick exactly one:
source /opt/ros/jazzy/setup.bash
# source /opt/ros/humble/setup.bash

mkdir -p ~/ai_ws/src
# Copy this entire ros2_ai_publisher folder into ~/ai_ws/src/
cd ~/ai_ws
sudo apt update
sudo apt install python3-colcon-common-extensions python3-rosdep python3-pytest
rosdep update
rosdep install --from-paths src --ignore-src -r -y --rosdistro "$ROS_DISTRO"
colcon build --packages-select ros2_ai_publisher --event-handlers console_direct+
source install/setup.bash
```

The folder `~/ai_ws/src/ros2_ai_publisher` must directly contain `package.xml`
and `CMakeLists.txt`. `package.xml` uses a placeholder maintainer address;
replace it before publishing your own release.

## 2. Run the offline example

Terminal 1 (source ROS and the workspace first):

```bash
ros2 launch ros2_ai_publisher ai_demo.launch.py
```

Wait for **AI bridge ready** and the C++ **Ready** messages. Terminal 2:

```bash
source /opt/ros/jazzy/setup.bash  # use humble if appropriate
source ~/ai_ws/install/setup.bash
ros2 topic echo /ai/output
```

Terminal 3 (same environment):

```bash
ros2 topic pub --once /ai/input std_msgs/msg/String \
  "{data: 'Explain how DVL and IMU help underwater navigation.'}"
```

Expected output:

```text
data: '[mock] Explain how DVL and IMU help underwater navigation.'
```

Start the output subscriber before sending the prompt: volatile topics do not
replay old responses. Send prompts one at a time. Errors can be observed with:

```bash
ros2 topic echo /ai/error
```

Individual executable equivalents, in separate sourced terminals:

```bash
ros2 run ros2_ai_publisher ai_publisher
ros2 run ros2_ai_publisher llm_bridge --ros-args -p backend:=mock
```

## 3. Enable OpenAI or LangChain

Use your distribution's **system Python** to retain ABI compatibility with
`rclpy` (normally Python 3.10 for Humble; 3.12 for Jazzy). Do not use a Conda
Python of a different version.

```bash
cd ~/ai_ws
sudo apt install python3-venv
python3 -m venv --system-site-packages .venv
source .venv/bin/activate
# Prevent colcon from treating the virtual environment as workspace sources.
touch .venv/COLCON_IGNORE
python -m pip install -r src/ros2_ai_publisher/requirements.txt
source /opt/ros/jazzy/setup.bash  # or humble
source install/setup.bash

# Input is hidden and is not recorded as a literal key in shell history.
read -rsp 'OpenAI API key: ' OPENAI_API_KEY; echo
export OPENAI_API_KEY
read -rp 'Model ID available to your API project: ' OPENAI_MODEL

ros2 launch ros2_ai_publisher ai_demo.launch.py \
  backend:=openai model:="$OPENAI_MODEL"
```

For the LangChain prompt-template → chat-model → text-parser chain, replace the
last command with:

```bash
ros2 launch ros2_ai_publisher ai_demo.launch.py \
  backend:=langchain model:="$OPENAI_MODEL"
```

Use the same topic commands as the offline example. The model is deliberately
not hard-coded: choose a text model available to your API project that supports
the Responses API. An API key with API billing/access is required; a ChatGPT
subscription alone is not API credit. Both live modes send prompts and
instructions to OpenAI and may incur usage charges. The key is read from the
environment, never from a ROS topic or YAML parameter. The default endpoint is
fixed to `https://api.openai.com/v1`; retries are disabled. `store=False` is
requested; that flag is not a general guarantee of zero data retention.

The installed bridge script uses `#!/usr/bin/env python3`, so activate the venv
in the terminal that launches it. No rebuild is needed when installing the
optional SDKs. `requirements.txt` defines supported version ranges, not a fully
reproducible lock; save `python -m pip freeze` for your own deployed environment.

## 4. Configuration

Bridge parameters are **read-only after startup**. Edit `config/params.yaml`
and rebuild, or pass `--ros-args -p name:=value` when starting `llm_bridge`.
The launch arguments `backend` and `model` override those two YAML settings.

| Parameter | Default | Meaning |
|---|---|---|
| `backend` | `mock` | `mock`, `openai`, or `langchain` |
| `model` | empty | Required live API model ID |
| `instructions` | concise robotics teacher | System instructions |
| `timeout_sec` | `30.0` | Positive SDK network timeout in seconds |
| `max_output_tokens` | `512` | Positive generation budget; reasoning may consume part of it |
| `max_prompt_chars` | `4000` | Positive prompt character limit after trimming |

The timeout is an SDK/network timeout, not a hard real-time deadline. On shutdown
an in-flight request is allowed to finish/time out. No automatic API retries
or application request queue are enabled. While an inference is pending, new
requests receive `busy: retry_after_current_response` on `ai/error`.

Namespace example:

```bash
ros2 launch ros2_ai_publisher ai_demo.launch.py namespace:=robot1
ros2 topic echo /robot1/ai/output
# Send input on /robot1/ai/input in another terminal.
```

## 5. Build and test

```bash
cd ~/ai_ws
source /opt/ros/jazzy/setup.bash  # or humble
colcon build --packages-select ros2_ai_publisher
source install/setup.bash
# Choose an unused domain so tests do not interact with a running demo.
ROS_DOMAIN_ID=91 colcon test --packages-select ros2_ai_publisher \
  --event-handlers console_direct+
colcon test-result --verbose
```

Tests perform no paid calls. They check backend contracts with SDK fakes and
run the **actual compiled C++ node** together with the Python mock bridge over
ROS DDS. They cover successful round trips, invalid prompts, busy handling,
provider failure recovery, and read-only configuration.

Optional tests use the actual installed SDKs with an intercepted HTTP transport
(no API calls). After activating the venv and installing `requirements.txt`:

```bash
cd ~/ai_ws/src/ros2_ai_publisher
PYTHONPATH="$PWD${PYTHONPATH:+:$PYTHONPATH}" python -m pytest test/optional -v
```

See [the verification report](docs/VERIFICATION.md) for what was actually run.
A GitHub Actions matrix is included for Humble and Jazzy; place this folder at
your repository root to activate `.github/workflows/ros-build.yml`. A supplied
workflow is not evidence that both distribution builds have already passed.

## 6. Code documentation and troubleshooting

- [Code walkthrough](docs/CODE_WALKTHROUGH.md): classes, methods, build/install flow.
- [Troubleshooting](docs/TROUBLESHOOTING.md): dependency, topic and API errors.
- [Verification report](docs/VERIFICATION.md): environment, commands and limitations.

This example has no request IDs and supports one active request per bridge.
For multiple clients, add custom request/response messages with correlation
IDs or use a ROS action before depending on response ownership. Cloud text
inference belongs outside a fast vehicle stabilization/PID loop.

## References

- [OpenAI text generation](https://developers.openai.com/api/docs/guides/text)
- [LangChain ChatOpenAI](https://docs.langchain.com/oss/python/integrations/chat/openai)
- [ROS 2 Humble documentation](https://docs.ros.org/en/humble/)
- [ROS 2 Jazzy documentation](https://docs.ros.org/en/jazzy/)

License: MIT. See `LICENSE`.
