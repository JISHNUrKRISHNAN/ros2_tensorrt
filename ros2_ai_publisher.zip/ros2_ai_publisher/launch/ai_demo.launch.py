"""Start the C++ publisher and the selected Python backend together."""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    config = os.path.join(get_package_share_directory("ros2_ai_publisher"),
                          "config", "params.yaml")
    return LaunchDescription([
        DeclareLaunchArgument("backend", default_value="mock",
                              choices=["mock", "openai", "langchain"]),
        DeclareLaunchArgument("model", default_value=""),
        DeclareLaunchArgument("namespace", default_value=""),
        Node(package="ros2_ai_publisher", executable="ai_publisher",
             namespace=LaunchConfiguration("namespace"), output="screen"),
        Node(package="ros2_ai_publisher", executable="llm_bridge",
             namespace=LaunchConfiguration("namespace"), output="screen",
             parameters=[config, {
                 "backend": ParameterValue(LaunchConfiguration("backend"), value_type=str),
                 "model": ParameterValue(LaunchConfiguration("model"), value_type=str),
             }]),
    ])
